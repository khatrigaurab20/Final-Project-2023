<template>
    <div class="properties">
        <h3 class="font-weight-bold  text-center mb-5">Nearby Properties</h3>
        <div class="map-modal">
            <i class="far fa-window-close" @click="closeMap"></i>
            <div id="map-content" class="border border-primary"></div>
        </div>
        <div class="col-11 m-auto">
            <div class="results row col-12  pt-0 m-0">
                <div
                    class="wrapper row  p-0 m-0 col-12"
                    v-if="AllData.length > 0"
                >
                    <div
                        class="row col-xl-4 col-md-6 m-0 "
                        v-for="p in AllData"
                        :key="p.index"
                    >
                        <div
                            href="#"
                            class="row  result-item shadow p-0 m-0 mb-4 border-light"
                        >
                            <div class="image col-12">
                                <img
                                    :src="'/storage/' + JSON.parse(p.images)[0]"
                                    class="card-img-top col-12"
                                    alt=""
                                />
                                <span
                                    class="rent-sticker bg-danger text-uppercase"
                                >
                                    {{ p.ad_type }}
                                </span>
                            </div>

                            <div class="res-desc col-12 p-3">
                                <h5
                                    class="card-title font-weight-bold pr-5 mb-3"
                                >
                                    {{ p.title }}
                                </h5>
                                <p class="card-text mb-1">
                                    <small class="material-icons">
                                        location_on
                                    </small>
                                    <small
                                        class="text-secondary text-capitalize"
                                    >
                                        {{ p.route }}, {{ p.locality }},{{
                                            p.country
                                        }}
                                    </small>
                                    <small
                                        class="badge rounded-pill bg-secondary p-1"
                                        @click="viewMap(p)"
                                    >
                                        View Map
                                        <i class="fa fa-map"></i>
                                    </small>
                                </p>
                                <p class="card-text mb-1">
                                    <small class="material-icons">
                                        phone
                                    </small>
                                    <small class="text-secondary">
                                        986*********
                                    </small>
                                </p>

                                <div class="price">
                                    <button
                                        class="border-primary bg-light text-primary font-weight-bold p-1"
                                    >
                                        RS {{ p.price }}
                                    </button>
                                </div>
                                <div class="get-details">
                                    <button
                                        class="btn btn-outline-danger btn-sm p-1"
                                        @click="viewDetails(p)"
                                    >
                                        View Details
                                    </button>
                                    <button
                                        class="btn btn-success btn-sm p-1"
                                        @click="showPayment(p)"
                                    >
                                        Get Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <PropertyDetail ref="detail"></PropertyDetail>
        <payment-form ref="payment"></payment-form>
    </div>
</template>

<script>
import PropertyDetail from "../properties/Detail";
import PaymentForm from "../payment/payment-form.vue";
import searchBox from "../../components/search.vue";
export default {
    components: {
        PropertyDetail,
        PaymentForm,
        searchBox
    },

    data() {
        return {
            showDetails: false,
            showMap: true,
            // searched data
            AllData: [],
            isLoading: false,
            form: {
                latitude: "",
                longitude: "",
                country: "",
                locality: "",
                route: "",
                price: "",
                furnishing: ""
            }
        };
    },
    mounted() {},
    created() {
        this.getLocation();
    },

    methods: {
        getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(this.showPosition);
            } else {
                x.innerHTML = "Geolocation is not supported by this browser.";
            }
        },
        showPosition(position) {
            this.getPropertyData(
                position.coords.latitude,
                position.coords.longitude
            );
        },
        async getPropertyData(lat, long) {
            var form = {
                latitude: lat,
                longitude: long
            };
            this.isLoading = true;
            try {
                var res = await axios.post("get-nearby-data", form);
                if (res.status == 200) {
                    this.AllData = res.data;
                }
            } catch (error) {
                console.log(error.message);
            }
        },
        async viewCount(id) {
            this.isLoading = true;
            try {
                var res = await axios.get("/view-count/" + id);
                console.log(res);
            } catch (error) {
                console.log(error.message);
            }
        },
        getSearchData() {
            this.getPropertyData();
        },

        // for payment
        showPayment(data) {
            this.$refs.payment.loadPayment(data);
        },
        viewDetails(elem) {
            console.log("====================================");
            console.log(elem);
            console.log("====================================");
            this.viewCount(elem.id);
            this.$refs.detail.loadData(elem);
        },
        getAddressData(addressData, placeResultData, id) {
            console.log(addressData);
            this.form.country = addressData.country;
            this.form.locality = addressData.locality;
            this.form.route = addressData.route;
            this.form.longitude = addressData.longitude;
            this.form.latitude = addressData.latitude;
        },

        viewMap(data) {
            console.log(parseFloat(data.latitude));
            $(".map-modal").css("display", "flex");
            var map;
            this.showMap = true;
            map = new google.maps.Map(document.getElementById("map-content"), {
                center: {
                    lat: parseFloat(data.latitude),
                    lng: parseFloat(data.longitude)
                },
                zoom: 15
            });
        },
        closeMap() {
            $(".map-modal").css("display", "none");
        },
        hideAddr() {
            this.form.country = null;
            this.form.locality = null;
            this.form.route = null;
            $("#addr-overlay").css("display", "none");
        }
    }
};
</script>

<style lang="scss" scoped>
.image {
    width: 100%;
    position: relative;
    padding-top: 56.25%;
    overflow: hidden;
    background-color: red;

    img {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        height: 100%;
        width: 100%;
        overflow: hidden;
        object-fit: cover;
    }
}
</style>
