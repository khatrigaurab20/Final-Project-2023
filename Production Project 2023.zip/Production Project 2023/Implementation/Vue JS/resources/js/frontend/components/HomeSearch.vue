<template>
    <div class="search-form col-xl-6 col-md-10 col-sm-12 col-12 m-auto">
        <div class="row col-12 m-0 text-light">
            <!-- <vue-google-autocomplete
                ref="address"
                id="map"
                classname="form-control"
                placeholder="Please type your address"
                v-on:placechanged="getAddressData"
                country="np"
                autocomplete="off"
            >
            </vue-google-autocomplete> -->
            <searchBox :form="form"></searchBox>
            <button class="btn btn-primary" @click="handleSubmit">
                <i class="fa fa-search text-white"></i>
            </button>
        </div>
    </div>
</template>

<script>
import VueGoogleAutocomplete from "vue-google-autocomplete";
import searchBox from "../../components/search.vue";
export default {
    components: { VueGoogleAutocomplete, searchBox },
    data() {
        return {
            address: "",
            form: {
                latitude: "",
                longitude: "",
                country: "",
                locality: "",
                route: "",
                price: "",
                furnishing: ""
            }
        };
    },
    mounted() {
        // this.$refs.address.focus();
        // document.getElementById("map").setAttribute("autocomplete", "off");
    },

    methods: {
        // async getAddressData(addressData, placeResultData, id) {
        //     this.address = addressData;
        // },
        handleSubmit() {
            window.location = `/properties?country=${this.form.country}&locality=${this.form.locality}&route=${this.form.route}`;
        }
    }
};
</script>
