<template>
    <div class="properties">
        <div class="map-modal">
            <i class="far fa-window-close" @click="closeMap"></i>
            <div id="map-content" class="border border-primary"></div>
        </div>
        <div class="col-11 m-auto">
            <div class="col-12 row p-0 m-0">
                <div class="col-xl-4 mb-5 ">
                    <div
                        class="row m-0 col-12  justify-content-start  bg-white shadow p-3"
                    >
                        <!-- <div
                            class="form-group position-relative overflow-hidden"
                        >
                            <vue-google-autocomplete
                                ref="address"
                                id="map"
                                classname="form-control"
                                placeholder="Please type your address"
                                v-on:placechanged="getAddressData"
                                country="np"
                                autocomplete="off"
                            >
                            </vue-google-autocomplete>
                            <div id="addr-overlay" @click="hideAddr()"></div>
                        </div> -->
                        <searchBox :form="form" ref="search"></searchBox>
                        <div class="form-group mt-2">
                            <label>Price Range (optional)</label>
                            <select v-model="form.price" class="form-control">
                                <option value="1000-10000"
                                    >Rs 1,000 - Rs 10,000</option
                                >
                                <option value="10000-20000"
                                    >Rs 10,000 - Rs 20,000</option
                                >
                                <option value="20000-30000"
                                    >Rs 20,000 - Rs 30,000</option
                                >
                                <option value="30000-40000"
                                    >Rs 30,000 - Rs 40,000</option
                                >
                                <option value="40000-50000"
                                    >Rs 40,000 - Rs 50,000</option
                                >
                                <option value="50000-100000"
                                    >Rs 50,000 - Rs 100,000</option
                                >
                                <option value="100000-500000"
                                    >Rs 100,000 - Rs 500,000</option
                                >
                            </select>
                        </div>
                        <div class="form-group mt-2">
                            <label>Furnishing Type (optional)</label>
                            <select
                                v-model="form.furnishing"
                                class="form-control"
                            >
                                <option value="full">Full Furnishing</option>
                                <option value="semi">Semi Furnishing</option>
                                <option value="non">Non Furnishing</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button
                                class="btn btn-primary mt-3 rounded-0"
                                @click="getSearchData"
                            >
                                <i class="fa fa-search"></i> SEARCH
                            </button>
                        </div>
                    </div>
                </div>

                <div class="results row col-xl-8  pt-0 m-0">
                    <div
                        class="no-data col-md-12 shadow bg-white pt-5 pb-5"
                        v-if="AllData.length == 0"
                    >
                        <h1 class="text-center text-muted">
                            <i class="far fa-frown display-1"></i>
                        </h1>
                        <h3 class="text-center text-muted">
                            No Any Property Found
                        </h3>
                    </div>
                    <div
                        class="wrapper row  p-0 m-0 col-12"
                        v-if="AllData.length > 0"
                    >
                        <div
                            class="row col-xl-12 m-0 "
                            v-for="p in AllData"
                            :key="p.index"
                        >
                            <div
                                href="#"
                                class="row  result-item bg-white shadow p-0 m-0 mb-4 border-light"
                            >
                                <div class="image col-md-4 p-0">
                                    <img
                                        :src="
                                            '/storage/' +
                                                JSON.parse(p.images)[0]
                                        "
                                        class="card-img-top col-12"
                                        alt=""
                                    />
                                    <span
                                        class="rent-sticker bg-danger text-uppercase"
                                    >
                                        {{ p.ad_type }}
                                    </span>
                                </div>
                                <div class="res-desc col-md-8 p-3">
                                    <h5
                                        class="card-title font-weight-bold pr-5 mb-3"
                                    >
                                        {{ p.title }}
                                    </h5>
                                    <p class="card-text mb-1">
                                        <small class="material-icons">
                                            location_on
                                        </small>
                                        <small
                                            class="text-secondary text-capitalize"
                                        >
                                            {{ p.route }}, {{ p.locality }},{{
                                                p.country
                                            }}
                                        </small>
                                        <small
                                            class="badge rounded-pill bg-secondary p-1"
                                            @click="viewMap(p)"
                                        >
                                            View Map
                                            <i class="fa fa-map"></i>
                                        </small>
                                    </p>
                                    <p class="card-text mb-1">
                                        <small class="material-icons">
                                            phone
                                        </small>
                                        <small class="text-secondary">
                                            986*********
                                        </small>
                                    </p>
                                    <div class="card-text mb-4">
                                        <h6 class="font-weight-bold">
                                            Facilities
                                        </h6>
                                        <small
                                            class="badge rounded-pill bg-primary text-capitalize ml-2"
                                            v-for="f in p.facilities.split(',')"
                                            :key="f.index"
                                        >
                                            {{ f }}
                                        </small>
                                    </div>
                                    <div class="price">
                                        <button
                                            class="border-primary bg-light text-primary font-weight-bold p-1"
                                        >
                                            RS {{ p.price }}
                                        </button>
                                    </div>
                                    <div class="get-details">
                                        <button
                                            class="btn btn-outline-danger btn-sm p-1"
                                            @click="viewDetails(p)"
                                        >
                                            View Details
                                        </button>
                                        <button
                                            class="btn btn-success btn-sm p-1"
                                            @click="showPayment(p)"
                                        >
                                            Get Details
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <PropertyDetail ref="detail"></PropertyDetail>
        <payment-form ref="payment"></payment-form>
    </div>
</template>

<script>
import VueGoogleAutocomplete from "vue-google-autocomplete";
import PropertyDetail from "./Detail";
import PaymentForm from "../payment/payment-form";
import searchBox from "../../components/search.vue";
export default {
    components: {
        VueGoogleAutocomplete,
        PropertyDetail,
        PaymentForm,
        searchBox
    },
    props: ["loc"],
    data() {
        return {
            showDetails: false,
            showMap: true,
            // searched data
            AllData: [],
            isLoading: false,
            form: {
                latitude: "",
                longitude: "",
                country: "",
                locality: "",
                route: "",
                price: "",
                furnishing: ""
            }
        };
    },
    mounted() {
        this.$refs.search.setAddress(this.form);
    },
    created() {
        if (this.loc) {
            var loc_info = JSON.parse(this.loc);
            this.form.country = loc_info.country;
            this.form.locality = loc_info.locality;
            this.form.route = loc_info.route;
            this.form.longitude = loc_info.longitude;
            this.form.latitude = loc_info.latitude;
        }

        this.getPropertyData();
    },

    methods: {
        async getPropertyData() {
            this.isLoading = true;
            try {
                var res = await axios.post("get-location-data", this.form);
                if (res.status == 200) {
                    this.AllData = res.data;
                }
            } catch (error) {
                console.log(error.message);
            }
        },
        getSearchData() {
            this.getPropertyData();
        },

        // for payment
        showPayment(data) {
            this.$refs.payment.loadPayment(data);
        },
        viewDetails(elem) {
            this.viewCount(elem.id);
            this.$refs.detail.loadData(elem);
        },
        getAddressData(addressData, placeResultData, id) {
            console.log(addressData);
            this.form.country = addressData.country;
            this.form.locality = addressData.locality;
            this.form.route = addressData.route;
            this.form.longitude = addressData.longitude;
            this.form.latitude = addressData.latitude;
        },

        async viewCount(id) {
            this.isLoading = true;
            try {
                var res = await axios.get("/view-count/" + id);
                console.log(res);
            } catch (error) {
                console.log(error.message);
            }
        },
        viewMap(data) {
            console.log(parseFloat(data.latitude));

            $(".map-modal").css("display", "flex");
            var map;
            this.showMap = true;
            map = new google.maps.Map(document.getElementById("map-content"), {
                center: {
                    lat: parseFloat(data.latitude),
                    lng: parseFloat(data.longitude)
                },
                zoom: 15
            });
        },
        closeMap() {
            $(".map-modal").css("display", "none");
        },
        hideAddr() {
            this.form.country = null;
            this.form.locality = null;
            this.form.route = null;
            $("#addr-overlay").css("display", "none");
        }
    }
};
</script>
