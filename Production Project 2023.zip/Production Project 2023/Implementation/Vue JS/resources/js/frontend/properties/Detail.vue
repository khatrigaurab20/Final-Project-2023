<template>
    <div class="detail-modal" v-if="showDetail">
        <i class="far fa-window-close" @click="displayDetail"></i>
        <div class="detail-container col-11 m-auto row mt-4">
            <div class="detail-gallery col-md-6">
                <VueSlickCarousel v-bind="settings" ref="carousel">
                    <div
                        class="swiper-slide"
                        v-for="d in images"
                        :key="d.index"
                    >
                        <img :src="'/storage/' + d" alt="" />
                    </div>
                </VueSlickCarousel>
                <div
                    class="slider-buttons row justify-content-between"
                    v-if="images.length > 0"
                >
                    <div class="col-6">
                        <button
                            @click="showNext"
                            class="border-0 text-primary"
                            style="font-size:30px"
                        >
                            <i class="fa fa-arrow-left"></i>
                        </button>
                    </div>
                    <div class="col-6">
                        <button
                            @click="showPrev"
                            class="float-right border-0 text-primary"
                            style="font-size:30px"
                        >
                            <i class="fa fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="detail-description col-md-6">
                <h2 class="col-11">{{ details_info.title }}</h2>
                <div class="property-information">
                    <table class="table table-striped">
                        <tbody>
                            <tr v-if="details_info.ad_type">
                                <td>Ad Type</td>
                                <td>{{ details_info.ad_type }}</td>
                            </tr>
                            <tr v-if="details_info.furnishing">
                                <td>Furnishing</td>
                                <td>
                                    {{ details_info.furnishing }} Funrnishing
                                </td>
                            </tr>

                            <tr v-if="details_info.address">
                                <td>Property Address</td>
                                <td>{{ details_info.address }}</td>
                            </tr>
                            <tr v-if="details_info.land_area">
                                <td>Land Area</td>
                                <td>{{ details_info.land_area }}</td>
                            </tr>
                            <tr v-if="details_info.building_area">
                                <td>Building Area</td>
                                <td>{{ details_info.building_area }}</td>
                            </tr>
                            <tr v-if="details_info.access_road">
                                <td>Access Road</td>
                                <td>{{ details_info.access_road }} Feet</td>
                            </tr>
                            <tr v-if="details_info.property_face">
                                <td>Property Face</td>
                                <td>{{ details_info.property_face }}</td>
                            </tr>
                            <tr>
                                <td>Facilities</td>
                                <td>
                                    <span
                                        class="badge rounded-pill bg-primary text-capitalize ml-2"
                                        v-for="f in details_info.facilities.split(
                                            ','
                                        )"
                                        :key="f.index"
                                    >
                                        {{ f }}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Price</td>
                                <td>Rs {{ details_info.price }}</td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Contact Number</td>
                                <td>
                                    <span>986********</span>
                                    <button
                                        @click="displayPayment(details_info)"
                                        class="btn btn-outline-success rounded-0"
                                    >
                                        Get Details Now
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="contact-information"></div>
            </div>
        </div>
    </div>
</template>

<script>
import VueSlickCarousel from "vue-slick-carousel";
import "vue-slick-carousel/dist/vue-slick-carousel.css";
// optional style for arrows & dots
import "vue-slick-carousel/dist/vue-slick-carousel-theme.css";
export default {
    components: { VueSlickCarousel },
    data() {
        return {
            showDetail: false,
            details_info: "",
            images: [],
            settings: {
                arrows: true
            }
        };
    },
    mounted() {},
    created() {},
    methods: {
        showNext() {
            this.$refs.carousel.next();
        },
        showPrev() {
            this.$refs.carousel.prev();
        },
        loadData(data) {
            console.log(true);
            this.details_info = data;
            this.images = JSON.parse(this.details_info.images);
            this.showDetail = true;
            $("body").css("overflow", "hidden");
        },
        displayDetail() {
            this.showDetail = false;
            $("body").css("overflow", "auto");
        },
        displayPayment(data) {
            this.showDetail = false;
            $("body").css("overflow", "auto");
            this.$parent.showPayment(data);
        }
    }
};
</script>
