<template>
    <div>
        <!-- Modal -->
        <loader v-if="isLoading"></loader>
        <div class="payment-modal" v-if="showPayment">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5
                            class="modal-title font-weight-bold"
                            id="exampleModalLabel"
                        >
                            {{ pay_info.title }}
                        </h5>
                        <button
                            type="button"
                            class="btn btn-close p-0"
                            @click="hidePayment"
                        >
                            <span class="material-icons">close</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="guidelines col-md-6 bg-light p-3 mb-3">
                                <div
                                    class="price border border-primary p-2 mb-3"
                                >
                                    <h2
                                        class="text-primary font-weight-bold mb-0 text-center"
                                    >
                                        Service Charge : Rs {{ form.price }}
                                    </h2>
                                </div>

                                <h3 class="mb-3 border-bottom pb-2">
                                    INFOMRATION
                                </h3>
                                <div class="d-flex flex-center mb-2">
                                    <span
                                        class="material-icons pr-3 text-success"
                                    >
                                        check_circle
                                    </span>
                                    <span
                                        >Fill Up A Form With The Basic Details
                                        About Your Personal Details</span
                                    >
                                </div>
                                <div class="d-flex flex-center mb-2">
                                    <span
                                        class="material-icons pr-3 text-success"
                                    >
                                        check_circle
                                    </span>
                                    <span
                                        >You Will be redirected to payment
                                        page.</span
                                    >
                                </div>
                                <div class="d-flex flex-center mb-2">
                                    <span
                                        class="material-icons pr-3 text-success"
                                    >
                                        check_circle
                                    </span>
                                    <span
                                        >After the payment is completed. You
                                        will get details about the property
                                        owner in your email.</span
                                    >
                                </div>
                                <div class="d-flex flex-center mb-2">
                                    <span
                                        class="material-icons pr-3 text-success"
                                    >
                                        check_circle
                                    </span>
                                    <span
                                        >Email may be in SPAM section. If you do
                                        not get email then please contact our
                                        customer service.</span
                                    >
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <div class="form-group mb-3">
                                    <label>Full Name</label>
                                    <input
                                        v-model="form.name"
                                        class="form-control"
                                        type="text"
                                        placeholder="John Doe"
                                    />
                                </div>
                                <div class="form-group mb-3">
                                    <label>Email</label>
                                    <input
                                        v-model="form.email"
                                        class="form-control"
                                        type="email"
                                        placeholder="email@example.com"
                                    />
                                </div>
                                <div class="row mb-3">
                                    <div class="form-group col-8">
                                        <label>Phone</label>
                                        <input
                                            class="form-control"
                                            type="number"
                                            placeholder="986********"
                                            v-model="form.phone_number"
                                            :disabled="showOTP"
                                        />
                                    </div>
                                    <div class="form-group col-4">
                                        <button
                                            class="btn btn-outline-primary"
                                            style="margin-top:23px;"
                                            @click="sendOTP"
                                            v-if="
                                                !showOTP && !this.OTP_verified
                                            "
                                        >
                                            SEND OTP
                                        </button>
                                        <div class="form-group">
                                            <label
                                                v-if="showOTP && !OTP_verified"
                                                >Code</label
                                            >
                                            <input
                                                class="form-control"
                                                type="number"
                                                v-model="form.OTP"
                                                v-if="showOTP && !OTP_verified"
                                            />

                                            <div
                                                v-if="OTP_verified"
                                                class="pt-2"
                                            >
                                                <br />
                                                <span>Verified</span>
                                                <span
                                                    class="material-icons pr-3 text-success"
                                                    style="font-size:14px"
                                                >
                                                    check_circle
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-8">
                                        <button
                                            class="btn btn-outline-primary"
                                            style="margin-top:23px;"
                                            @click="verifyOTP"
                                            v-if="showOTP"
                                        >
                                            Verify OTP
                                        </button>
                                        <small
                                            v-if="OTP_error && !OTP_verified"
                                            class="text-danger"
                                        >
                                            {{ OTP_error }}
                                        </small>
                                    </div>
                                </div>
                                <div class="payment-info mb-4  p-3">
                                    <h4>Payment Method</h4>
                                    <div
                                        class="payment-methods bg-light d-flex p-3 mt-3"
                                    >
                                        <div class="card-text">
                                            <input
                                                style="width:30px !important;transform: scale(1.5);"
                                                type="radio"
                                                v-model="form.payment_method"
                                                value="esewa"
                                            />
                                            <img
                                                style="height:50px"
                                                src="/assets/images/esewa.png"
                                                alt=""
                                            />
                                        </div>
                                        <div class="card-text ml-3">
                                            <input
                                                style="width:30px !important;transform: scale(1.5);"
                                                type="radio"
                                                v-model="form.payment_method"
                                                value="khalti"
                                            />
                                            <img
                                                style="height:50px"
                                                src="/assets/images/khalti.png"
                                                alt=""
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input
                                        type="checkbox"
                                        style="width:30px !important;transform: scale(1.5);"
                                        value="true"
                                        v-model="form.accept_terms"
                                    />
                                    <span
                                        >I accept
                                        <a href="" class="border-bottom"
                                            >Terms and Conditions</a
                                        ></span
                                    >
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            class="btn btn-primary"
                            @click="proceedPayment"
                        >
                            Proceed For Payment
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div id="recaptcha-container"></div>
    </div>
</template>

<script>
import KhaltiCheckout from "khalti-checkout-web";
import loader from "../../components/loader";
export default {
    components: {
        loader
    },
    data() {
        return {
            showPayment: false,
            isLoading: false,
            OTP_error: "",
            showOTP: false,
            OTP_verified: false,
            pay_info: {},
            form: {
                property_id: "",
                price: process.env.MIX_SERVICE_CHARGE,
                email: "",
                name: "",
                phone_number: "",
                OTP: "",
                payment_method: "",
                accept_terms: "",
                device_data: ""
            }
        };
    },

    created() {
        this.loadDeviceData();
    },

    methods: {
        openForm() {
            $("#getDetail").modal("show");
        },
        closeForm() {
            $("#getDetail").modal("hide");
        },
        async sendOTP() {
            try {
                var res = await axios.post("/send-otp", this.form);
                this.showOTP = true;
            } catch (error) {
                alert(error.message);
            }
        },
        async verifyOTP() {
            this.OTP_error = "";
            try {
                var res = await axios.post("/verify-otp", this.form);
                if (res.data.status) {
                    this.showOTP = false;
                    this.OTP_verified = true;
                } else {
                    this.OTP_error = "INVALID OTP CODE";
                }
            } catch (error) {
                alert(error.message);
            }
        },
        proceedPayment() {
            if (this.validateForm()) {
                if (this.form.payment_method == "khalti") {
                    this.setPaymentSession();
                    this.payKhalti();
                }
            }
        },
        payKhalti() {
            this.isLoading = true;
            let config = {
                // replace this key with yours
                publicKey: process.env.MIX_KHALTI_PUBLIC,
                productIdentity: "1234567890",
                productName: "room",
                productUrl: "http://127.0.0.1/properties",
                eventHandler: {
                    onSuccess(payload) {
                        // hit merchant api for initiating verfication
                        if (payload.idx) {
                            var data = {
                                response: payload
                            };

                            axios
                                .post("/khalti/payment/verify", data)
                                .then(res => {
                                    console.log(res);
                                    if (res.data.status == true) {
                                        window.location = "/payment/success";
                                    } else {
                                        alert(
                                            "Something Went Wrong. Please Try Again Later"
                                        );
                                        window.reload();
                                    }
                                })
                                .catch(error => {
                                    alert(
                                        "Something Went Wrong. Please Try Again Later"
                                    );
                                    window.reload();
                                });
                        }
                    },
                    // onError handler is optional
                    onError(error) {
                        alert("Something Went Wrong. Please Try Again Later");
                        checkout.hide();
                        console.log(error);
                    },
                    onClose() {
                        console.log("widget is closing");
                    }
                },
                paymentPreference: [
                    "KHALTI",
                    "EBANKING",
                    "MOBILE_BANKING",
                    "CONNECT_IPS",
                    "SCT"
                ]
            };
            let checkout = new KhaltiCheckout(config);
            checkout.show({ amount: this.form.price * 100 });
        },
        async setPaymentSession() {
            // for saving user data;
            try {
                var data = {
                    data: this.form
                };
                var res = await axios.post("/payment/save-session", data);
                console.log(res);
            } catch (error) {
                console.log(error.message);
            }
        },
        loadDeviceData() {
            var client = new ClientJS();
            var data = {
                browser_data: client.getBrowserData(),
                fingerprint: client.getFingerprint(),
                user_agent: client.getUserAgent(),
                browser: client.getBrowser(),
                os: client.getOS(),
                device: client.getDevice(),
                device_type: client.getDeviceType(),
                is_mobile: client.isMobile(),
                time_zone: client.getTimeZone(),
                langugage: client.getLanguage()
            };
            this.form.device_data = data;
        },
        validateForm() {
            var check = true;
            if (!this.OTP_verified) {
                alert("Please Verify Your Phone Number.");
                check = false;
            }
            if (this.form.name == "") {
                alert("Please Fill Name Field.");
                check = false;
            }
            if (this.form.email == "") {
                alert("Please Fill Email Field.");
                check = false;
            }
            if (this.form.payment_method == "") {
                alert("Please Fill Payment method Field.");
                check = false;
            }
            if (this.form.phone_number == "") {
                alert("Please Fill Phone Number Field.");
                check = false;
            }
            if (!this.form.accept_terms) {
                alert("Please Accept Terms And Conditions.");
                check = false;
            }

            return check;
        },
        loadPayment(data) {
            this.showPayment = true;
            this.pay_info = data;
            this.form.property_id = data.id;
            console.log(this.pay_info);
            $("body").css("overflow", "hidden");
        },
        hidePayment() {
            this.showPayment = false;
            $("body").css("overflow", "auto");
        }
    }
};
</script>
