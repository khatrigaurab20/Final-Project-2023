<template>
    <div class="form">
        <!-- Modal -->

        <div class="search row justify-content-between col-12 m-auto p-3">
            <div class="sort">
                <div class="form-group row">
                    <select
                        v-model="sortBy"
                        class="form-control form-control-sm"
                        @change="getData"
                    >
                        <option value="all">All</option>
                        <option value="admin">Admin</option>
                        <option value="locked">Locked Users</option>
                    </select>
                </div>
            </div>
            <div class="s-form row">
                <div class="form-group">
                    <select
                        v-model="search_col"
                        class="form-control form-control-sm"
                    >
                        <option
                            :value="s"
                            v-for="s in searchFields"
                            :key="s.index"
                            >{{ s }}</option
                        >
                    </select>
                </div>
                <div class="form-group">
                    <input
                        class="form-control form-control-sm"
                        type="text"
                        v-model="keyword"
                        @keyup.enter="getData"
                    />
                </div>
                <div class="form-group">
                    <button @click="getData" class="btn btn-secondary btn-sm">
                        Search
                    </button>
                </div>
            </div>
        </div>
        <b-table
            class="bg-white"
            id="my-table"
            :current-page="currentPage"
            :items="allUsers"
            :fields="fields"
        >
            <template #cell(status)="data">
                <span
                    class="badge badge-pill bg-success text-white"
                    v-if="data.item.is_locked === 0"
                >
                    Active
                </span>
                <span class="badge badge-pill bg-danger text-white" v-else>
                    Locked
                </span>
            </template>

            <template #cell(role)="data">
                <span v-if="data.item.is_admin == 0">User</span>
                <span v-if="data.item.is_admin == 1 && data.item.is_admin == 1"
                    >Admin</span
                >
            </template>

            <template #cell(contact)="data">
                <i class="fa fa-envelope text-primary"></i>
                <span> {{ data.item.email }}</span> <br />
                <i class="fa fa-phone text-danger"></i>
                <span> {{ data.item.phone_number }}</span>
            </template>

            <template #cell(created_at)="data">
                {{ data.item.created_at | moment("MMMM DD YYYY, h:mm:ss a") }}
            </template>
            <template #cell(action)="data">
                <button class="btn btn-sm btn-danger" @click="lock(data.item)">
                    <i class="fa fa-key"></i>
                </button>
                <!-- <button
                    class="btn btn-sm btn-primary"
                    @click="viewDetail(data.item)"
                >
                    <i class="fa fa-eye"></i>
                </button> -->
            </template>
        </b-table>

        <b-pagination
            align="center"
            v-if="usersPagination.total > usersPagination.perPage"
            v-model="currentPage"
            :per-page="usersPagination.perPage"
            :total-rows="usersPagination.total"
            @change="getData"
        ></b-pagination>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
    data() {
        return {
            errors: [],
            sortBy: "all",
            keyword: "",
            searchFields: ["name", "email", "phone", "created_at"],
            search_col: "name",
            fields: [
                "name",
                "contact",
                "address",
                "role",
                "status",
                "created_at",
                "action"
            ],
            currentPage: 1
        };
    },
    created() {
        this.fetechAllUsers({
            page: 1,
            sort_by: this.sortBy,
            keyword: this.keyword,
            searchBy: this.search_col
        });
        this.currentPage = this.usersPagination.currentPage;
    },
    computed: mapGetters(["allUsers", "usersPagination"]),
    methods: {
        ...mapActions(["fetechAllUsers", "deleteTransaction", "lockUser"]),
        getData(page = 1) {
            this.fetechAllUsers({
                page: page,
                sort_by: this.sortBy,
                keyword: this.keyword,
                searchBy: this.search_col
            });
        },

        lock(payload) {
            if (confirm("Are you sure want to lock this user ?")) {
                this.lockUser(payload);
            }
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}
.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}
</style>
