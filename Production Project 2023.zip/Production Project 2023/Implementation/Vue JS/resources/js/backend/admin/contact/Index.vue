<template>
    <div class="form">
        <!-- Modal -->

        <div class="search row justify-content-between col-12 m-auto p-3">
            <div class="sort">
                <div class="form-group row">
                    <select
                        v-model="sortBy"
                        class="form-control form-control-sm"
                        @change="getData"
                    >
                        <option value="all">All</option>
                        <option value="seen">Seen</option>
                        <option value="notseen">Not Seen</option>
                    </select>
                </div>
            </div>
            <div class="s-form row">
                <div class="form-group">
                    <select
                        v-model="search_col"
                        class="form-control form-control-sm"
                    >
                        <option
                            :value="s"
                            v-for="s in searchFields"
                            :key="s.index"
                            >{{ s }}</option
                        >
                    </select>
                </div>
                <div class="form-group">
                    <input
                        class="form-control form-control-sm"
                        type="text"
                        v-model="keyword"
                        @keyup.enter="getData"
                    />
                </div>
                <div class="form-group">
                    <button @click="getData" class="btn btn-secondary btn-sm">
                        Search
                    </button>
                </div>
            </div>
        </div>
        <b-table
            class="bg-white"
            id="my-table"
            :current-page="currentPage"
            :items="allContacts"
            :fields="fields"
        >
            <template #cell(is_seen)="data">
                <span
                    class="badge badge-pill bg-success text-white"
                    v-if="data.item.is_seen == 1"
                >
                    Seen
                </span>
                <span class="badge badge-pill bg-danger text-white" v-else>
                    Not Seen
                </span>
            </template>

            <template #cell(message)="data">
                <label class="break">
                    {{ data.item.message }}
                </label>
            </template>

            <template #cell(created_at)="data">
                {{ data.item.created_at | moment("MMMM DD YYYY, h:mm:ss a") }}
            </template>
            <template #cell(action)="data">
                <button
                    :class="
                        data.item.is_seen == 1
                            ? 'btn btn-sm btn-success'
                            : 'btn btn-sm btn-danger'
                    "
                    @click="approve(data.item)"
                >
                    <i class="fa fa-check"></i>
                </button>
                <!-- <button
                    class="btn btn-sm btn-primary"
                    @click="viewDetail(data.item)"
                >
                    <i class="fa fa-eye"></i>
                </button> -->
            </template>
        </b-table>

        <b-pagination
            align="center"
            v-if="contactPagination.total > contactPagination.perPage"
            v-model="currentPage"
            :per-page="contactPagination.perPage"
            :total-rows="contactPagination.total"
            @change="getData"
        ></b-pagination>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
    data() {
        return {
            errors: [],
            sortBy: "all",
            keyword: "",
            searchFields: ["phone", "email", "name"],
            search_col: "phone",
            fields: [
                "name",
                "email",
                "phone",
                "message",
                "is_seen",
                "created_at",
                "action"
            ],
            currentPage: 1
        };
    },
    created() {
        this.fetchAllContacts({
            page: 1,
            sort_by: this.sortBy,
            keyword: this.keyword,
            searchBy: this.search_col
        });
        this.currentPage = this.contactPagination.currentPage;
    },
    computed: mapGetters(["allContacts", "contactPagination"]),
    methods: {
        ...mapActions(["fetchAllContacts", "approveContact"]),
        getData(page = 1) {
            this.fetchAllContacts({
                page: page,
                sort_by: this.sortBy,
                keyword: this.keyword,
                searchBy: this.search_col
            });
        },

        approve(payload) {
            this.approveContact(payload);
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}
.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}
.break {
    display: block;
    width: 300px !important;
    overflow-wrap: break-word;
    word-break: break-all;
    white-space: normal !important;
}

.table td,
.table th {
    font-size: 0.8125rem;
    white-space: normal !important;
}
</style>
