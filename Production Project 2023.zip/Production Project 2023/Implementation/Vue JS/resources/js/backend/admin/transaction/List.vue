<template>
    <div class="form">
        <!-- Modal -->
        <div
            class="modal fade"
            id="invoiceModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
        >
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title " id="exampleModalLabel">
                            Transaction Detail
                        </h5>
                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                        >
                            <i class="fa fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xl-12">
                                <h3 class="bg-primary text-white p-2">
                                    User Detail
                                </h3>
                                <table class="table table-striped ">
                                    <tr>
                                        <td>Name</td>
                                        <td>
                                            {{ invoiceDetail.details.name }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td>
                                            {{ invoiceDetail.details.email }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Phone Number</td>
                                        <td>
                                            {{
                                                invoiceDetail.details
                                                    .phone_number
                                            }}
                                        </td>
                                    </tr>
                                </table>
                            </div>

                            <div class="col-xl-12">
                                <h3 class="bg-primary text-white p-2">
                                    Payment Method Detail
                                </h3>
                                <table class="table table-striped ">
                                    <tr>
                                        <td>Name</td>
                                        <td>
                                            <img
                                                v-if="
                                                    invoiceDetail.payment_type ==
                                                        'khalti'
                                                "
                                                width="80px"
                                                src="/assets/images/khalti.png"
                                                alt=""
                                            />
                                            {{ invoiceDetail.payment_type }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Reference Id</td>
                                        <td>
                                            {{ invoiceDetail.reference_id }}
                                        </td>
                                    </tr>
                                    <tr v-if="invoiceDetail.response">
                                        <td>Response</td>
                                        <td>
                                            <p
                                                style="overflow:scroll;width:350px;"
                                            >
                                                {{
                                                    JSON.parse(
                                                        invoiceDetail.response
                                                    )
                                                }}
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </div>

                            <div class="col-xl-12">
                                <h3 class="bg-primary text-white p-2">
                                    User Device Detail
                                </h3>
                                <table class="table table-striped ">
                                    <tr>
                                        <td>Browser</td>
                                        <td>
                                            {{ invoiceDetail.details.browser }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Country</td>
                                        <td>
                                            {{
                                                invoiceDetail.details
                                                    .country_code
                                            }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Device Fingerprint</td>
                                        <td>
                                            {{
                                                invoiceDetail.details
                                                    .fingerprint
                                            }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Ip Adderess</td>
                                        <td>
                                            {{
                                                invoiceDetail.details.ip_address
                                            }}
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Operating System</td>
                                        <td>{{ invoiceDetail.details.os }}</td>
                                    </tr>

                                    <tr
                                        v-if="
                                            invoiceDetail.details.is_mobile == 1
                                        "
                                    >
                                        <td>Device</td>
                                        <td>
                                            {{ invoiceDetail.details.device }}
                                            ({{
                                                invoiceDetail.details
                                                    .device_type
                                            }})
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Time Zone</td>
                                        <td>
                                            {{
                                                invoiceDetail.details.time_zone
                                            }}
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-xl-12">
                                <h3 class="bg-primary text-white p-2">
                                    Property Detail
                                </h3>
                                <table class="table table-striped ">
                                    <tr>
                                        <td>Property Name</td>
                                        <td>
                                            {{ invoiceDetail.property.title }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Property image</td>
                                        <td>
                                            <img
                                                width="200px"
                                                :src="
                                                    '/storage/' +
                                                        getImage(
                                                            invoiceDetail
                                                                .property.images
                                                        )
                                                "
                                                alt=""
                                            />
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="search row justify-content-between col-12 m-auto p-3">
            <div class="sort">
                <div class="form-group  row">
                    <select
                        v-model="sortBy"
                        class="form-control form-control-sm"
                        @change="getData"
                    >
                        <option value="all">All</option>
                        <option value="success">Success</option>
                        <option value="failed">Failed</option>
                    </select>
                </div>
            </div>
            <div class="s-form row">
                <div class="form-group">
                    <select
                        v-model="search_col"
                        class="form-control form-control-sm"
                    >
                        <option
                            :value="s"
                            v-for="s in searchFields"
                            :key="s.index"
                            >{{ s }}</option
                        >
                    </select>
                </div>
                <div class="form-group">
                    <input
                        class="form-control form-control-sm"
                        type="text"
                        v-model="keyword"
                        @keyup.enter="getData"
                    />
                </div>
                <div class="form-group">
                    <button @click="getData" class="btn btn-secondary btn-sm">
                        Search
                    </button>
                </div>
            </div>
        </div>
        <b-table
            class="bg-white"
            id="my-table"
            :current-page="currentPage"
            :items="allTransactions"
            :fields="fields"
        >
            <template #cell(payment_type)="data">
                <img
                    v-if="data.item.payment_type == 'khalti'"
                    width="80px"
                    src="/assets/images/khalti.png"
                    alt=""
                />
                {{ data.item.payment_type }}
            </template>
            <template #cell(status)="data">
                <span
                    class="badge badge-pill bg-success text-white"
                    v-if="data.item.status == 1 || data.item.status == '1'"
                >
                    SUUCCESS
                </span>
                <span class="badge badge-pill bg-danger text-white" v-else>
                    FAILED
                </span>
            </template>
            <template #cell(created_at)="data">
                {{ data.item.created_at | moment("MMMM DD YYYY, h:mm:ss a") }}
            </template>
            <template #cell(price)="data"> Rs {{ data.item.price }} </template>
            <template #cell(fingerprint)="data">
                {{ data.item.details.fingerprint }}
            </template>
            <template #cell(action)="data">
                <button
                    class="btn btn-sm btn-primary"
                    @click="viewDetail(data.item)"
                >
                    <i class="fa fa-eye"></i>
                </button>
                <button
                    class="btn btn-sm btn-info"
                    @click="sendMailUser(data.item.id)"
                >
                    <i class="fa fa-envelope"></i>
                </button>
            </template>
        </b-table>

        <b-pagination
            align="center"
            v-if="transactionPagination.total > transactionPagination.perPage"
            v-model="currentPage"
            :per-page="transactionPagination.perPage"
            :total-rows="transactionPagination.total"
            @change="getData"
        ></b-pagination>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
    data() {
        return {
            errors: [],
            sortBy: "all",
            keyword: "",
            searchFields: [
                "phone_number",
                "reference_id",
                "fingerprint",
                "created_at"
            ],
            search_col: "phone_number",
            fields: [
                "payment_type",
                "reference_id",
                "fingerprint",
                "price",
                "status",
                "created_at",
                "action"
            ],
            currentPage: 1,
            invoiceDetail: { details: {}, property: {} }
        };
    },
    created() {
        this.fetchTransactions({
            page: 1,
            sort_by: this.sortBy,
            keyword: this.keyword,
            searchBy: this.search_col
        });
        this.currentPage = this.transactionPagination.currentPage;
    },
    computed: mapGetters(["allTransactions", "transactionPagination"]),
    methods: {
        ...mapActions(["fetchTransactions", "sendMail"]),
        getData(page = 1) {
            this.fetchTransactions({
                page: page,
                sort_by: this.sortBy,
                keyword: this.keyword,
                searchBy: this.search_col
            });
        },
        sendMailUser(id) {
            if (
                confirm("Are you sure want to send mail to this user email ?")
            ) {
                this.sendMail({ id: id });
            }
        },
        viewDetail(data) {
            this.invoiceDetail = data;
            $("#invoiceModal").modal("show");
        },
        getImage(elem) {
            if (elem) {
                return JSON.parse(elem)[0];
            }
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}
.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}
</style>
