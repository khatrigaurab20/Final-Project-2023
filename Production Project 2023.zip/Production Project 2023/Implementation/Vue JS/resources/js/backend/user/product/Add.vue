<template>
    <div class="form">
        <notifications group="foo" />

        <div class="bg-white shadow">
            <h3 class="col-12 bg-primary text-white p-2">
                Basic Information
            </h3>
            <div class="p-3">
                <div class="row">
                    <div class="form-group col-xl-10">
                        <label>Title</label>
                        <input
                            :class="
                                errors.title
                                    ? 'form-control border-danger'
                                    : 'form-control'
                            "
                            type="text"
                            v-model="form.title"
                        />
                        <span
                            class="bg-danger d-block col-12 p-1  text-white"
                            v-if="errors.title"
                            >{{ errors.title[0] }}
                        </span>
                    </div>
                    <div class="form-group col-xl-2">
                        <label>Status</label>
                        <select v-model="form.status" class="form-control">
                            <option value="1">Active</option>
                            <option value="0">In Active</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-xl-10">
                        <label class="">Category</label>
                        <select
                            :class="
                                errors.category
                                    ? 'form-control border-danger'
                                    : 'form-control'
                            "
                            v-model="form.category"
                        >
                            <option value="business & shop">
                                Busniess & Shop
                            </option>
                            <option value="flat & apartment">
                                flat and apartment
                            </option>
                            <option value="house & building">
                                House and building
                            </option>
                            <option value="office & commercial space">
                                Office & commercial Space
                            </option>
                            <option value="hostel">
                                Hostel
                            </option>
                        </select>
                        <span
                            class="bg-danger d-block col-12 p-1 text-white"
                            v-if="errors.category"
                            >{{ errors.category[0] }}
                        </span>
                    </div>
                    <div class="form-group col-xl-2">
                        <label class="">Price (Rs)</label>
                        <input
                            :class="
                                errors.price
                                    ? 'form-control border-danger'
                                    : 'form-control'
                            "
                            type="number"
                            v-model="form.price"
                        />
                        <span
                            class="bg-danger d-block col-12 p-1 text-white"
                            v-if="errors.price"
                            >{{ errors.price[0] }}
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="">Description</label>
                    <input
                        :class="
                            errors.description
                                ? 'form-control border-danger'
                                : 'form-control'
                        "
                        type="text"
                        v-model="form.description"
                    />
                    <span
                        class="bg-danger d-block col-12 p-1 text-white"
                        v-if="errors.description"
                        >{{ errors.description[0] }}
                    </span>
                </div>

                <div class="form-group">
                    <label class="font-weight-bold ">Image</label>
                    <input
                        :class="
                            errors.image
                                ? 'form-control border-danger'
                                : 'form-control'
                        "
                        @change="previewImage"
                        id="image-file"
                        ref="files"
                        type="file"
                        accept="image/jpeg, image/jpg, image/JPG, image/JPEG"
                        multiple
                    />
                    <span
                        class="bg-danger d-block col-12 p-1 text-white"
                        v-if="errors.image"
                    >
                        <p v-for="e in errors.image" :key="e.index" class="m-0">
                            {{ e }}
                        </p>
                    </span>
                </div>
                <div id="img-container" class="row col-12">
                    <div
                        class="preview-image"
                        v-for="(image, index) in demoImage"
                        :key="index"
                    >
                        <img :src="image" alt="" />
                        <span class="fa fa-times" @click="removeImage(index)">
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white row col-12 p-0 m-0 shadow mt-3">
            <h3 class="col-12 bg-primary text-white p-2">
                Property Information
            </h3>
            <div class="form-group col-6">
                <label class="">Type Of Ad</label>
                <select
                    :class="
                        errors.ad_type
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    v-model="form.ad_type"
                >
                    <option value="rent">For Rent</option>
                    <option value="sale">For Sale</option>
                </select>
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.ad_type"
                    >{{ errors.ad_type[0] }}
                </span>
            </div>
            <div class="form-group col-6">
                <label class="">Furnishing</label>
                <select
                    :class="
                        errors.furnishing
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    v-model="form.furnishing"
                >
                    <option value="full">Full Furnished</option>
                    <option value="semi">Non Furnished</option>
                    <option value="non">Semi Furnished</option>
                </select>
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.furnishing"
                    >{{ errors.furnishing[0] }}
                </span>
            </div>
            <div class="form-group col-6">
                <label class="">Number Of Rooms</label>
                <input
                    :class="
                        errors.rooms
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    type="number"
                    v-model="form.rooms"
                />
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.rooms"
                    >{{ errors.rooms[0] }}
                </span>
            </div>
            <div class="form-group col-6">
                <label class="">Property Face</label>
                <select
                    :class="
                        errors.property_face
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    v-model="form.property_face"
                >
                    <option value="east">East</option>
                    <option value="west">West</option>
                    <option value="north">North</option>
                    <option value="south">South</option>
                </select>
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.property_face"
                    >{{ errors.property_face[0] }}
                </span>
            </div>
            <div class="form-group col-6">
                <label class="">Access Road (Feet)</label>
                <input
                    :class="
                        errors.access_road
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    type="number"
                    v-model="form.access_road"
                />
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.access_road"
                    >{{ errors.access_road[0] }}
                </span>
            </div>
            <div class="form-group col-6">
                <label class="">Area Of Land</label>
                <input
                    :class="
                        errors.land_area
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    type="text"
                    v-model="form.land_area"
                    placeholder="120 square feet"
                />
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.land_area"
                    >{{ errors.land_area[0] }}
                </span>
            </div>

            <div class="form-group col-12">
                <label class="">Facilities</label>
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.facilities"
                    >{{ errors.facilities[0] }}
                </span>

                <div class="row">
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="backup power"
                        />
                        Backup Power
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="cctv security"
                        />
                        Cctv Security
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="garden"
                        />
                        Garden
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="gym | aerobic"
                        />
                        Gym | Aerobic
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="others"
                        />
                        Others
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="parking space"
                        />
                        Parking Space
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="security guards"
                        />
                        Security Guards
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="swimming pool"
                        />
                        Swimming Pool
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-4 col-2">
                        <input
                            type="checkbox"
                            v-model="form.facilities"
                            value="water supply"
                        />
                        Water Supply
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white row col-12 p-0 m-0 shadow mt-3">
            <h3 class="col-12 bg-primary text-white p-2">
                Contact Information
            </h3>
            <div class="form-group col-12">
                <label class="">Contact Number</label>
                <input
                    :class="
                        errors.contact
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    type="number"
                    v-model="form.contact"
                />
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.contact"
                    >{{ errors.contact[0] }}
                </span>
            </div>
            <!-- <div class="form-group col-12">
                <label class="">Property Address</label>
                <input
                    :class="
                        errors.address
                            ? 'form-control border-danger'
                            : 'form-control'
                    "
                    type="text"
                    v-model="form.address"
                />
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.address"
                    >{{ errors.address[0] }}
                </span>
            </div> -->
            <div class="form-group col-12">
                <label>Property Address</label>
                <vue-google-autocomplete
                    ref="address"
                    id="map"
                    classname="form-control"
                    placeholder="Please type your address"
                    v-on:placechanged="getAddressData"
                    country="np"
                    autocomplete="off"
                >
                </vue-google-autocomplete>
                <div
                    id="addr-overlay"
                    v-if="showAddrOverlay"
                    @click="hideAddr()"
                ></div>
                <span
                    class="bg-danger d-block col-12 p-1 text-white"
                    v-if="errors.country"
                    >Invalid Address Field. Please Add Google Suggested Address.
                </span>
            </div>
        </div>

        <div class="bg-white  shadow mt-3">
            <h3 class="col-12 bg-primary text-white p-2">
                SEO Information (optional)
            </h3>
            <div class="p-3">
                <div class="form-group">
                    <label class="">Title</label>
                    <input
                        class="form-control"
                        type="text"
                        v-model="form.seo_title"
                    />
                </div>
                <div class="form-group">
                    <label class="">Description</label>
                    <input
                        class="form-control"
                        type="text"
                        v-model="form.seo_description"
                    />
                </div>
                <div class="form-group">
                    <label class="">Keywords</label>
                    <input
                        class="form-control"
                        type="text"
                        v-model="form.seo_keywords"
                    />
                </div>
            </div>
        </div>

        <div class="form-group mt-3  row col-12 justify-content-between">
            <a
                href="/user/product-list"
                class="btn btn-secondary"
                v-if="formState == 'edit'"
            >
                <i class="fa fa-arrow-left"></i>
                Go Back
            </a>
            <button
                class="btn btn-primary d-flex justify-content-center"
                @click="submitForm()"
            >
                <span>SUBMIT </span> &nbsp;
                <i class="ni ni-send"></i>
            </button>
        </div>
    </div>
</template>

<script>
import VueGoogleAutocomplete from "vue-google-autocomplete";
export default {
    components: {
        VueGoogleAutocomplete
    },
    props: ["edit_data"],
    data() {
        return {
            errors: [],
            demoImage: [],
            formState: "save",
            showAddrOverlay: false,
            form: {
                title: "",
                description: "",
                category: "",

                image: [],
                editId: "",
                prevImages: "",

                country: "",
                locality: "",
                route: "",
                contact: "",

                facilities: [],
                ad_type: "",
                furnishing: "",
                property_face: "",
                access_road: "",
                land_area: "",
                rooms: 0,

                status: 0,
                price: "",

                // meta
                seo_title: "",
                seo_description: "",
                seo_keywords: ""
            }
        };
    },
    created() {
        if (this.edit_data) {
            this.showAddrOverlay = true;
        }
    },
    mounted() {
        this.$refs.address.focus();
        if (this.edit_data) {
            this.formState = "edit";
            var data = JSON.parse(this.edit_data);

            this.form.title = data.title;
            this.form.description = data.description;
            this.form.category = data.category;

            var arr_img = [];
            JSON.parse(data.images).forEach(element => {
                arr_img.push("/storage/" + element);
                this.form.image.push(element);
            });
            this.demoImage = arr_img;
            this.form.editId = data.id;

            this.form.country = data.detail.country;
            this.form.locality = data.detail.locality;
            this.form.route = data.detail.route;
            this.form.longitude = data.detail.longitude;
            this.form.latitude = data.detail.latitude;

            document.getElementById(
                "addr-overlay"
            ).innerHTML = `${this.form.route}, ${this.form.locality}, ${this.form.country}`;

            var fac = data.detail.facilities.split(",");
            this.form.facilities = fac;
            this.form.ad_type = data.detail.ad_type;

            this.form.furnishing = data.detail.furnishing;
            this.form.property_face = data.detail.property_face;
            this.form.access_road = data.detail.access_road;
            this.form.land_area = data.detail.land_area;
            this.form.contact = data.detail.contact;
            this.form.status = data.status;
            this.form.price = data.detail.price;
            this.form.rooms = data.detail.rooms;

            // meta
            this.form.seo_title = data.seo_title;
            this.form.seo_description = data.seo_description;
            this.form.seo_keywords = data.seo_keywords;
        }
    },

    methods: {
        getAddressData(addressData, placeResultData, id) {
            this.form.country = addressData.country;
            this.form.locality = addressData.locality;
            this.form.route = addressData.route;
            this.form.longitude = addressData.longitude;
            this.form.latitude = addressData.latitude;
        },
        submitForm() {
            this.errors = [];

            const formData = new FormData();
            var self = this;

            for (let i = 0; i < this.form.image.length; i++) {
                let file = self.form.image[i];
                formData.append("image[" + i + "]", file);
            }

            formData.append("id", this.form.editId);
            formData.append("title", this.form.title);
            formData.append("description", this.form.description);
            formData.append("category", this.form.category);

            formData.append("facilities", this.form.facilities);

            if (this.form.country !== null) {
                formData.append("country", this.form.country);
            }

            formData.append("locality", this.form.locality);
            formData.append("route", this.form.route);
            formData.append("latitude", this.form.latitude);
            formData.append("longitude", this.form.longitude);

            formData.append("ad_type", this.form.ad_type);
            formData.append("furnishing", this.form.furnishing);
            formData.append("property_face", this.form.property_face);
            formData.append("access_road", this.form.access_road);
            formData.append("land_area", this.form.land_area);
            formData.append("contact", this.form.contact);
            formData.append("status", this.form.status);
            formData.append("price", this.form.price);
            formData.append("rooms", this.form.rooms);
            // meta
            formData.append("seo_title", this.form.seo_title);
            formData.append("seo_description", this.form.seo_description);
            formData.append("seo_keywords", this.form.seo_keywords);

            const config = {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            };

            if (this.formState == "save") {
                axios
                    .post("/user/product", formData, config)
                    .then(res => {
                        if (res.data.status) {
                            Vue.$toast.open("Item Added Successfully");
                            this.resetForm();
                        }
                    })
                    .catch(error => {
                        window.scroll(0, 0);
                        alert("Please fill all required fields.");
                        if (error.response.data.errors) {
                            this.errors = error.response.data.errors;
                        }
                    });
            } else {
                axios
                    .post("/user/edit/product", formData, config)
                    .then(res => {
                        if (res.data.status) {
                            Vue.$toast.open("Item Updated Successfully");
                            window.setTimeout(() => {
                                window.location = "/user/product-list";
                            }, 1000);
                        }
                    })
                    .catch(error => {
                        console.log(error.response.data);
                        window.scroll(0, 0);
                        alert("Please fill all required fields.");

                        if (error.response.data.errors) {
                            this.errors = error.response.data.errors;
                        }
                    });
            }
        },
        previewImage(e) {
            // console.log(this.form.image);
            // this.demoImage = [];
            // this.form.image = [];
            var images = this.$refs.files.files;
            for (let i = 0; i < images.length; i++) {
                // console.log(images[i]);
                this.form.image.push(images[i]);
                //image preview
                var reader = new FileReader();
                reader.onload = e => {
                    this.demoImage.push(e.target.result);
                };
                reader.readAsDataURL(e.target.files[i]);
            }
        },
        removeImage(index) {
            this.form.image.splice(index, 1);
            this.demoImage.splice(index, 1);
        },
        resetForm() {
            this.errors = [];
            this.demoImage = [];

            this.form.title = "";
            this.form.description = "";
            this.form.category = "";

            this.form.image = [];
            this.form.editId = "";
            this.form.prevImages = "";

            this.form.address = "";
            this.form.facilities = [];
            this.form.ad_type = "";
            this.form.furnishing = "";
            this.form.property_face = "";
            this.form.access_road = "";
            this.form.land_area = "";
            this.form.contact = "";
            this.form.price = "";
            this.form.rooms = "";

            // meta
            this.form.seo_title = "";
            this.form.seo_description = "";
            this.form.seo_keywords = "";
        },
        hideAddr() {
            this.form.country = null;
            this.form.locality = null;
            this.form.route = null;
            this.showAddrOverlay = false;
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}

.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}

#addr-overlay {
    background-color: white;
    height: 40px;
    width: 90%;
    position: absolute;
    top: 35px;
    left: 25px;
    display: flex;
    align-items: center;
}
</style>
