<template>
    <div class="form">
        <notifications group="foo" />
        <div class="search row justify-content-between col-12 m-auto p-3">
            <div class="sort">
                <div class="form-group  row">
                    <select
                        v-model="sortBy"
                        class="form-control form-control-sm"
                        @change="getData"
                    >
                        <option value="all">All Property</option>
                        <option value="active">Active Property</option>
                        <option value="inactive">InActive Property</option>
                        <option
                            value="admin"
                            v-if="isadmin == 1 || isadmin == '1'"
                        >
                            Admin Property
                        </option>
                        <option value="approved">
                            Approved Property
                        </option>
                        <option value="notapproved">
                            Not Approved Property
                        </option>
                    </select>
                </div>
            </div>
            <div class="s-form row">
                <div class="form-group">
                    <select
                        v-model="search_col"
                        class="form-control form-control-sm"
                    >
                        <option
                            :value="s"
                            v-for="s in searchFields"
                            :key="s.index"
                            >{{ s }}</option
                        >
                    </select>
                </div>
                <div class="form-group">
                    <input
                        class="form-control form-control-sm"
                        type="text"
                        v-model="keyword"
                        @keyup.enter="getData"
                    />
                </div>
                <div class="form-group">
                    <button @click="getData" class="btn btn-secondary btn-sm">
                        Search
                    </button>
                </div>
            </div>
        </div>
        <b-table
            class="bg-white"
            id="my-table"
            :current-page="currentPage"
            :items="allProducts"
            :fields="fields"
        >
            <template #cell(images)="data">
                <img
                    class="rounded"
                    :src="'/storage/' + JSON.parse(data.item.images)[0]"
                    alt="image"
                    width="100px"
                    height="100px"
                    style="object-fit:cover"
                />
            </template>
            <template #cell(created_at)="data">
                {{ data.item.created_at | moment("dddd, MMMM Do YYYY") }}
            </template>
            <template #cell(add_type)="data">
                <span class="text-capitalize">
                    {{ data.item.detail.ad_type }}
                </span>
            </template>
            <template #cell(category)="data">
                <span class="text-capitalize">
                    {{ data.item.category }}
                </span>
            </template>
            <template #cell(status)="data">
                <span
                    class="badge badge-pill bg-success text-white"
                    v-if="data.item.status == 1"
                >
                    Active
                </span>
                <span class="badge badge-pill bg-danger text-white" v-else>
                    InActive</span
                >
                <br />

                <span
                    class="badge badge-pill bg-success text-white"
                    v-if="data.item.is_approved == 1"
                >
                    Approved
                </span>
                <span class="badge badge-pill bg-danger text-white" v-else>
                    Approval Pending
                </span>
            </template>
            <template #cell(action)="data">
                <button
                    class="btn btn-sm btn-primary"
                    @click="editItem(data.item.id)"
                >
                    <i class="fa fa-edit"></i>
                </button>

                <button
                    class="btn btn-sm btn-danger"
                    @click="deleteItem(data.item.id)"
                >
                    <i class="fa fa-trash"></i>
                </button>

                <button
                    v-if="isadmin == 1 || isadmin == '1'"
                    :class="
                        data.item.is_approved == 1
                            ? 'btn-danger btn btn-sm'
                            : 'btn-success  btn btn-sm'
                    "
                    @click="approveItem(data.item.id)"
                >
                    <i
                        class="fa fa-times"
                        v-if="data.item.is_approved == 1"
                    ></i>
                    <i class="fa fa-check" v-else></i>
                </button>
            </template>
        </b-table>

        <b-pagination
            align="center"
            v-if="pagination.totalProducts > pagination.perPage"
            v-model="currentPage"
            :per-page="pagination.perPage"
            :total-rows="pagination.totalProducts"
            @change="getData"
        ></b-pagination>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
    props: ["isadmin"],
    data() {
        return {
            errors: [],
            sortBy: "all",
            keyword: "",
            searchFields: ["title", "category"],
            search_col: "title",
            fields: [
                "images",
                "title",
                // "category",
                "add_type",
                "status",
                "views",
                "created_at",
                "action"
            ],
            currentPage: 1
        };
    },
    created() {
        this.fetchProducts({
            page: 1,
            sort_by: this.sortBy,
            keyword: this.keyword,
            search_col: this.search_col
        });
        this.currentPage = this.pagination.currentPage;
    },
    computed: mapGetters(["allProducts", "pagination"]),
    methods: {
        ...mapActions(["fetchProducts", "deleteProduct", "approveProduct"]),
        getData(page = 1) {
            this.fetchProducts({
                page: page,
                sort_by: this.sortBy,
                keyword: this.keyword,
                search_col: this.search_col
            });
        },
        deleteItem(id) {
            if (confirm("Are you sure want to delete this item")) {
                this.deleteProduct({ id: id });
            }
        },
        editItem(id) {
            window.location = "/user/product/" + id;
        },
        approveItem(id) {
            this.approveProduct({ id: id });
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}
.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}
</style>
