<template>
    <div class="form">
        <div
            class="modal fade"
            id="invoiceModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
        >
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title " id="exampleModalLabel">
                            Property Detail
                        </h5>
                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                        >
                            <i class="fa fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-xl-12">
                                <table class="table table-striped ">
                                    <tr>
                                        <td>Property title</td>
                                        <td>
                                            {{ invoiceDetail.title }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Decription</td>
                                        <td>
                                            {{ invoiceDetail.description }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Images</td>
                                        <td v-if="invoiceDetail.images">
                                            <img
                                                class="p-1"
                                                width="200px"
                                                height="150px"
                                                style="object-fit:cover"
                                                v-for="i in JSON.parse(
                                                    invoiceDetail.images
                                                )"
                                                :src="'/storage/' + i"
                                                :key="i.index"
                                            />
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div
            class="modal fade"
            id="reportModal"
            tabindex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
        >
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">
                            Report User
                        </h5>
                        <button @click="hideReport" class="close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <div class="form-group">
                                <label class="form-control">
                                    Name : {{ reportData.user.name }}
                                </label>
                                <label class="form-control">
                                    Phone : {{ reportData.user.phone_number }}
                                </label>
                            </div>
                            <label>Message</label>
                            <textarea
                                rows="5"
                                class="form-control"
                                v-model="reportData.message"
                            >
                            </textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-secondary"
                            @click="hideReport"
                        >
                            Close
                        </button>
                        <button
                            type="button"
                            class="btn btn-primary"
                            @click="reportUser()"
                        >
                            Save changes
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="search row justify-content-between col-12 m-auto p-3">
            <div class="sort">
                <div class="form-group  row">
                    <select
                        v-model="sortBy"
                        class="form-control form-control-sm"
                        @change="getData"
                    >
                        <option value="all">All</option>
                        <option value="reported">Reported</option>
                        <option value="notreported">Not Reported</option>
                    </select>
                </div>
            </div>
            <div class="s-form row">
                <div class="form-group">
                    <select
                        v-model="search_col"
                        class="form-control form-control-sm"
                    >
                        <option
                            :value="s"
                            v-for="s in searchFields"
                            :key="s.index"
                            >{{ s }}</option
                        >
                    </select>
                </div>
                <div class="form-group">
                    <input
                        class="form-control form-control-sm"
                        type="text"
                        v-model="keyword"
                        @keyup.enter="getData"
                    />
                </div>
                <div class="form-group">
                    <button @click="getData" class="btn btn-secondary btn-sm">
                        Search
                    </button>
                </div>
            </div>
        </div>
        <b-table
            class="bg-white"
            id="my-table"
            :current-page="currentPage"
            :items="allInquires"
            :fields="fields"
        >
            <template #cell(property)="data">
                <img
                    width="150px"
                    :src="'/storage/' + getImage(data.item.images)"
                    alt=""
                />
                <button
                    class="d-block btn btn-sm btn-primary rounded-0"
                    @click="viewDetail(data.item)"
                >
                    <i class="fa fa-eye"> View Detail</i>
                </button>
            </template>

            <template #cell(date)="data">
                {{ data.item.created_at | moment("MMMM DD YYYY, h:mm:ss a") }}
            </template>
            <template #cell(action)="data">
                <button
                    class="btn btn-sm btn-danger"
                    @click="showReport(data.item)"
                    v-if="data.item.is_reported == 0"
                >
                    Report User <i class="far fa-flag"></i>
                </button>
                <button
                    class="btn btn-sm btn-success"
                    v-if="data.item.is_reported == 1"
                >
                    Reported <i class="far fa-flag"></i>
                </button>
            </template>
        </b-table>

        <b-pagination
            align="center"
            v-if="inquiresPagination.total > inquiresPagination.perPage"
            v-model="currentPage"
            :per-page="inquiresPagination.perPage"
            :total-rows="inquiresPagination.total"
            @change="getData"
        ></b-pagination>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
    data() {
        return {
            errors: [],
            sortBy: "all",
            keyword: "",
            searchFields: ["phone_number", "email", "name"],
            search_col: "phone_number",
            fields: [
                "name",
                "email",
                "phone_number",
                "property",
                "date",
                "action"
            ],
            currentPage: 1,
            invoiceDetail: { details: {}, property: {} },
            reportData: {
                user: {},
                message: ""
            }
        };
    },
    created() {
        this.fetchInquires({
            page: 1,
            sort_by: this.sortBy,
            keyword: this.keyword,
            searchBy: this.search_col
        });
        this.currentPage = this.inquiresPagination.currentPage;
    },
    computed: mapGetters(["allInquires", "inquiresPagination"]),
    methods: {
        ...mapActions(["fetchInquires", "sendReport"]),
        getData(page = 1) {
            this.fetchInquires({
                page: page,
                sort_by: this.sortBy,
                keyword: this.keyword,
                searchBy: this.search_col
            });
        },

        viewDetail(data) {
            this.invoiceDetail = data;
            $("#invoiceModal").modal("show");
        },
        showReport(data) {
            this.reportData.user = data;
            $("#reportModal").modal("show");
        },
        hideReport() {
            $("#reportModal").modal("hide");
        },
        reportUser() {
            if (!this.reportData.message) {
                alert("please fill message field");
                return false;
            }
            var res = this.sendReport(this.reportData);
            this.hideReport();
            this.reportData.message = "";
        },
        getImage(elem) {
            if (elem) {
                return JSON.parse(elem)[0];
            }
        }
    }
};
</script>

<style scoped>
.preview-image {
    position: relative;
    width: 100px !important;
    height: 100px !important;
    overflow: hidden;
    padding: 0px !important;
    border: 2px solid white;
}
.preview-image span {
    position: absolute;
    top: 10;
    right: 0px;
    padding: 3px;
    background-color: #2a6efd;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
}

a {
    padding: 5px;
    font-size: 20px;
}
</style>
