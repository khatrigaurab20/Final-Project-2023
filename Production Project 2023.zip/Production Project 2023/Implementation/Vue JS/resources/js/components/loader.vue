<template>
    <div class="loader-body" v-if="setLoading">
        <!-- <div class="loader"></div> -->
        <div id="loader5"></div>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
    computed: mapGetters(["setLoading"])
};
</script>

<style lang="scss" scoped>
.loader-body {
    height: 100vh;
    width: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    background-color: rgba(255, 255, 255, 0.7);
    display: flex;
    flex-direction: column;
    justify-content: center;
    z-index: 9999;
}
/* .loader {
    margin: auto;
    border: 16px solid #f3f3f3;
    border-radius: 50%;
    border-top: 16px solid #3498db;
    width: 120px;
    height: 120px;
    -webkit-animation: spin 1.5s linear infinite; /* Safari */
/* animation: spin 1.5s linear infinite; */
/* }  */

#loader5 {
    width: 35px;
    height: 35px;
    margin: auto;
    background-color: #5e72e4;
    animation: flip 1.2s linear infinite;
}
@keyframes flip {
    0% {
        transform: perspective(120px) rotateX(0deg) rotateY(0deg);
    }
    50% {
        transform: perspective(120px) rotateX(-180.1deg) rotateY(0deg);
    }
    100% {
        transform: perspective(120px) rotateX(-180deg) rotateY(-179.9deg);
    }
}
</style>
