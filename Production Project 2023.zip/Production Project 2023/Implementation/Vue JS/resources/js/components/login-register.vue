<template>
    <div class="login" id="login">
        <!-- Modal -->
        <div
            class="modal fade"
            id="loginModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
        >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">
                            Login / Register
                        </h5>
                        <button
                            type="button"
                            class="btn-close bg-white border-0"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                        >
                            <span class="material-icons ">
                                close
                            </span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-register-tab d-flex">
                            <div
                                id="login-tab"
                                class="tab1 col-6 bg-primary text-center text-light p-3"
                                @click="toggleTab('login-tab')"
                            >
                                Login
                            </div>
                            <div
                                id="register-tab"
                                class="tab1 col-6 bg-light text-center text-dark p-3"
                                @click="toggleTab('register-tab')"
                            >
                                Register
                            </div>
                        </div>

                        <div
                            class="login-form mt-4"
                            v-if="active_tab == 'login'"
                        >
                            <div class="form-group mb-3">
                                <p
                                    v-for="e in login_error"
                                    class="text-danger bg-light mb-0"
                                    :key="e.index"
                                >
                                    {{ e }}
                                </p>
                            </div>
                            <div class="form-group">
                                <label for="name">Email</label>
                                <input
                                    class="form-control  mt-1"
                                    type="email"
                                    v-model="login_form.email"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <label for="name">Password</label>
                                <input
                                    class="form-control  mt-1"
                                    type="password"
                                    v-model="login_form.password"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <button
                                    class="btn btn-outline-primary col-12 p-3"
                                    @click="login"
                                >
                                    Login
                                </button>
                            </div>
                        </div>

                        <div
                            class="register-form mt-4"
                            v-if="active_tab == 'register'"
                        >
                            <div class="form-group mb-3">
                                <p
                                    v-for="e in register_error"
                                    class="text-danger bg-light mb-0"
                                    :key="e.index"
                                >
                                    {{ e }}
                                </p>
                            </div>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input
                                    class="form-control  mt-1"
                                    type="email"
                                    v-model="signup_form.name"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <label for="email">Email</label>
                                <input
                                    class="form-control  mt-1"
                                    type="email"
                                    v-model="signup_form.email"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <label for="phone">Mobile Number</label>
                                <input
                                    class="form-control  mt-1"
                                    type="text"
                                    v-model="signup_form.phone_number"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <label for="password">Password</label>
                                <input
                                    class="form-control  mt-1"
                                    type="password"
                                    v-model="signup_form.password"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <label for="confirm">Confirm Password</label>
                                <input
                                    class="form-control  mt-1"
                                    type="password"
                                    v-model="signup_form.password_confirmation"
                                />
                            </div>
                            <div class="form-group mt-3">
                                <button
                                    @click="register"
                                    class="btn btn-outline-primary col-12 p-3"
                                >
                                    Register
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "list",
    data() {
        return {
            isLoading: false,
            register_error: "",
            login_error: "",
            //login_form
            active_tab: "login",
            categortylist: [],
            userError: false,
            passError: false,
            login_form: {
                email: "",
                password: ""
            },
            signup_form: {
                country_code: "+977",
                name: "",
                email: "",
                password: "",
                password_confirmation: "",
                phone_number: ""
            }
        };
    },
    mounted() {},
    created() {},
    methods: {
        closeLogin() {
            $("#loginModal").modal("hide");
        },
        toggleTab(tab) {
            $("#" + tab).removeClass("bg-light text-dark");
            $("#" + tab).addClass("bg-primary text-light");

            if (tab == "login-tab") {
                $("#register-tab").removeClass("bg-primary text-light");
                $("#register-tab").addClass("bg-light text-dark");
                this.active_tab = "login";
            } else {
                $("#login-tab").removeClass("bg-primary text-light");
                $("#login-tab").addClass("bg-light text-dark");
                this.active_tab = "register";
            }
        },
        register() {
            axios
                .post("/register", this.signup_form)
                .then(res => {
                    this.closeLogin();
                    window.location = "/user";
                })
                .catch(error => {
                    this.register_error = error.response.data.errors;
                });
        },
        login() {
            axios
                .post("/login", this.login_form)
                .then(res => {
                    this.closeLogin();
                    window.location = "/user";
                })
                .catch(error => {
                    this.login_error = error.response.data.errors;
                });
        }
    }
};
</script>

<style lang="scss" scoped></style>
