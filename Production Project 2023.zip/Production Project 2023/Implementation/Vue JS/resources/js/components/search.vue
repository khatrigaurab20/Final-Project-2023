<template>
    <div class="form-group geocode-box">
        <input
            type="text"
            v-model="address"
            @keyup="getLocation"
            @click="clearLocation"
            class="form-control"
        />
        <div class="geocode-result shadow" v-if="showGeoCode">
            <div
                class="gc-item"
                v-for="g in geoCodeResult"
                :key="g.index"
                @click="selectGeoCode(g)"
            >
                <p v-if="g.properties.country_a == 'NPL'">
                    <i class="fas fa-map-marker-alt text-primary"></i>
                    {{ g.properties.label }}
                </p>
            </div>
            <p class="spinner" v-if="isLoading">
                <i class="fas fa-circle-notch fa-spin"></i>
            </p>
        </div>
    </div>
</template>

<script>
export default {
    props: ["form"],
    data() {
        return {
            showGeoCode: false,
            isLoading: false,
            geoCodeResult: {},
            address: ""
        };
    },
    methods: {
        async getLocation() {
            if (this.address.length > 3) {
                this.isLoading = true;
                this.showGeoCode = true;
                var link = `https://app.geocodeapi.io/api/v1/autocomplete?apikey=4ed21720-e3f9-11eb-8ea7-bb6c489c05fa&text=${this.address}`;
                var headers = {
                    "Content-Type": "application/x-www-form-urlencoded"
                };

                try {
                    var res = await axios.get(link, { crossdomain: true });
                    this.geoCodeResult = res.data.features;
                    this.isLoading = false;
                    // console.log(res.data);
                } catch (error) {
                    console.log(error.message);
                    this.isLoading = false;
                }
            } else {
                this.isLoading = false;
                this.showGeoCode = false;
            }
        },
        selectGeoCode(elem) {
            var data = elem.properties;
            this.address = data.name + ", " + data.county + ", " + data.country;
            this.form.locality = data.county;
            this.form.route = data.name;
            this.form.country = data.country;
            this.form.latitude = elem.geometry.coordinates[0];
            this.form.longitude = elem.geometry.coordinates[1];
            this.showGeoCode = false;
        },

        clearLocation() {
            this.address = "";
        },
        setAddress(data) {
            this.address =
                data.route + ", " + data.locality + ", " + data.country;
        }
    }
};
</script>

<style lang="scss" scoped>
.geocode-box {
    position: relative;
    .geocode-result {
        position: absolute;
        top: 50px;
        left: 0px;
        background-color: white;
        height: 200px;
        width: 100%;
        z-index: 9999;
        overflow-y: auto;
        border: 1px solid #dddddd;

        .gc-item {
            p {
                padding: 10px;
                border-bottom: 1px solid #dddddd;
                cursor: pointer;
                margin-bottom: 0px;
                color: black;
                &:hover {
                    background-color: #dddddd;
                }
            }
        }
        .spinner {
            text-align: center;
        }
    }
}
</style>
