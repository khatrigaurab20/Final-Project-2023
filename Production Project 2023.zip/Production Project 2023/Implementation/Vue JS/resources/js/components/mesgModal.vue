<template>
    <div class="mesgModal">
        <b-modal v-model="getModalState">{{ getMessageModal }}</b-modal>
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
    computed: mapGetters(["getModalState", "getMessageModal"]),
    created() {
        console.log("modal");
    },
    methods: {}
};
</script>
